from pymongo import MongoClient
import os

# Global MongoDB client and collections
client = None
db = None
attendance_col = None
students_col = None
users_collection = None

def init_mongo_client(app):
    """Initialize MongoDB client and collections"""
    global client, db, attendance_col, students_col, users_collection
    
    # MongoDB connection from environment variables
    mongodb_uri = os.environ.get('MONGODB_URI', "mongodb://localhost:27017/")
    mongodb_db = os.environ.get('MONGODB_DB', "attendance_db")
    
    client = MongoClient(mongodb_uri)
    db = client[mongodb_db]
    attendance_col = db["attendance"]
    students_col = db["students"]
    users_collection = db["faculty"]
    
    # Store collections in app context for access in routes
    app.mongo_client = client
    app.db = db
    app.attendance_col = attendance_col
    app.students_col = students_col
    app.users_collection = users_collection

def get_collections():
    """Get MongoDB collections"""
    return {
        'attendance': attendance_col,
        'students': students_col,
        'users': users_collection
    } 