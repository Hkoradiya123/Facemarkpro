from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, current_app
from werkzeug.utils import secure_filename
import os
import pickle
import numpy as np
from ..services.face_recognition import FaceRecognitionService
from ..db.mongo_client import get_collections
import pandas as pd

bp = Blueprint('students', __name__)

@bp.route('/students')
def students():
    """Display all students for the logged-in faculty"""
    from flask import session
    
    faculty_email = session.get('faculty_email')
    if not faculty_email:
        return redirect('/login')

    # Get faculty name
    faculty_map = pd.read_csv('faculty_users.csv')
    faculty_map['faculty_email'] = faculty_map['faculty_email'].str.strip().str.lower()
    faculty_map['faculty_name'] = faculty_map['faculty_name'].str.strip().str.lower()
    faculty_row = faculty_map[faculty_map['faculty_email'] == faculty_email.strip().lower()]
    if faculty_row.empty:
        flash("Faculty not found.", "error")
        return redirect('/login')
    faculty_name = faculty_row.iloc[0]['faculty_name']

    # Get all classes taught by this faculty
    df = pd.read_csv('timetable.csv')
    df['faculty_name'] = df['faculty_name'].str.strip().str.lower()
    faculty_df = df[df['faculty_name'] == faculty_name]
    # Get all unique (branch, semester, section) tuples
    class_tuples = faculty_df[['branch', 'semester', 'section']].drop_duplicates().to_records(index=False)

    # Fetch all students in these classes
    collections = get_collections()
    students = []
    for branch, semester, section in class_tuples:
        students_cursor = collections['students'].find({
            "branch": branch,
            "semester": int(semester),
            "section": section
        })
        for s in students_cursor:
            students.append({
                "roll_no": str(s.get("roll_no")),
                "name": str(s.get("name")),
                "branch": str(branch),
                "semester": int(semester),
                "section": str(section)
            })
    return render_template('students.html', students=students, faculty=faculty_name)

@bp.route('/register_student_face', methods=['GET', 'POST'])
def register_student_face():
    """Register a student with face photos"""
    from flask import session
    
    faculty_email = session.get('faculty_email')
    if not faculty_email:
        return redirect('/login')

    # Get faculty name
    faculty_map = pd.read_csv('faculty_users.csv')
    faculty_map['faculty_email'] = faculty_map['faculty_email'].str.strip().str.lower()
    faculty_map['faculty_name'] = faculty_map['faculty_name'].str.strip().str.lower()
    faculty_row = faculty_map[faculty_map['faculty_email'] == faculty_email.strip().lower()]
    if faculty_row.empty:
        flash("Faculty not found.", "error")
        return redirect('/login')
    faculty_name = faculty_row.iloc[0]['faculty_name']
    
    collections = get_collections()
    branches = ['CE', 'CSE', 'IT', 'ECE']
    semesters = [1, 2, 3, 4, 5, 6, 7, 8]
    message = None
    error = None
    selected_branch = None
    selected_semester = None
    students = []

    if request.method == 'POST':
        branch = request.form.get('branch')
        semester = request.form.get('semester')
        selected_branch = branch
        selected_semester = semester
        # Filter students for dropdown
        if branch and semester:
            students = list(collections['students'].find({"branch": branch, "semester": int(semester)}, {"_id": 0}))
        else:
            students = list(collections['students'].find({}, {"_id": 0}))
        student_id = request.form.get('student_id')
        new_name = request.form.get('new_name').strip()
        new_roll_no = request.form.get('new_roll_no').strip()
        section = None
        if student_id:
            student = collections['students'].find_one({"roll_no": student_id})
            if not student:
                error = "Selected student not found."
            else:
                name = student['name']
                roll_no = student['roll_no']
                semester = student['semester']
                branch = student['branch']
                section = student.get('section', 'A')
        elif new_name and new_roll_no:
            name = new_name
            roll_no = new_roll_no
            section = 'A'
            if not collections['students'].find_one({"roll_no": roll_no}):
                collections['students'].insert_one({
                    "roll_no": roll_no,
                    "name": name,
                    "semester": int(semester),
                    "branch": branch,
                    "section": section
                })
        else:
            error = "Please select or enter student details."
        photos = [request.files.get(f'photo{i}') for i in range(1, 4)]
        if not error and (not all(photos) or not all(photo and photo.filename for photo in photos)):
            error = "Please upload 3 face photos."
        if not error:
            face_service = FaceRecognitionService()
            encodings = []
            for idx, photo in enumerate(photos):
                filename = secure_filename(f"{roll_no}_{name}_face{idx+1}.jpg")
                save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                photo.save(save_path)
                import cv2
                img = cv2.imread(save_path)
                if img is None:
                    error = f"Failed to read uploaded image {filename}."
                    break
                rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                faces = face_service.get_faces(rgb)
                if not faces:
                    error = f"No face found in {filename}."
                    break
                encodings.append(faces[0].normed_embedding)
            
            if not error and len(encodings) == 3:
                avg_encoding = np.mean(encodings, axis=0)
                
                # Check if this face is already registered in any class
                split_dir = current_app.config['SPLIT_DIR']
                os.makedirs(split_dir, exist_ok=True)
                
                # Get all pickle files in split_encodings directory
                all_pickle_files = [f for f in os.listdir(split_dir) if f.endswith('.pickle')]
                existing_registration = None
                
                for pickle_file in all_pickle_files:
                    pickle_path = os.path.join(split_dir, pickle_file)
                    try:
                        with open(pickle_path, 'rb') as f:
                            data = pickle.load(f)
                            existing_encodings = data.get('encodings', [])
                            existing_metadata = data.get('metadata', [])
                            
                            if existing_encodings:
                                # Compare with existing encodings
                                for i, existing_encoding in enumerate(existing_encodings):
                                    distance = np.linalg.norm(avg_encoding - existing_encoding)
                                    if distance < 0.85:  # Same tolerance as face recognition
                                        existing_student = existing_metadata[i]
                                        existing_class = pickle_file.replace('.pickle', '')
                                        existing_registration = {
                                            'student_name': existing_student.get('name', 'Unknown'),
                                            'student_roll': existing_student.get('roll_no', 'Unknown'),
                                            'class': existing_class,
                                            'distance': distance
                                        }
                                        break
                                        
                    except (ModuleNotFoundError, ImportError, ValueError) as e:
                        # Skip incompatible files
                        continue
                    except Exception as e:
                        # Skip other errors
                        continue
                    
                    if existing_registration:
                        break
                
                # If face is already registered in another class
                if existing_registration:
                    error = f"Face already registered! This face belongs to {existing_registration['student_name']} ({existing_registration['student_roll']}) in class {existing_registration['class']}. Distance: {existing_registration['distance']:.3f}"
                else:
                    # Proceed with registration in the selected class
                    pickle_path = os.path.join(split_dir, f"{branch}_{semester}.pickle")
                    if os.path.exists(pickle_path):
                        try:
                            with open(pickle_path, 'rb') as f:
                                data = pickle.load(f)
                        except (ModuleNotFoundError, ImportError, ValueError) as e:
                            # Handle numpy version incompatibility
                            print(f"Warning: Could not load existing pickle file due to version incompatibility: {e}")
                            print("Creating new pickle file...")
                            data = {"encodings": [], "metadata": []}
                    else:
                        data = {"encodings": [], "metadata": []}
                    
                    new_metadata = {"roll_no": roll_no, "name": name, "semester": int(semester), "branch": branch, "section": section}
                    filtered = [(e, m) for e, m in zip(data["encodings"], data["metadata"]) if m.get("roll_no") != roll_no]
                    data["encodings"] = [e for e, m in filtered]
                    data["metadata"] = [m for e, m in filtered]
                    data["encodings"].append(avg_encoding)
                    data["metadata"].append(new_metadata)
                    with open(pickle_path, 'wb') as f:
                        pickle.dump(data, f)
                    message = f"Student {name} ({roll_no}) registered successfully!"
        # Refresh students list for the selected branch/semester
        if selected_branch and selected_semester:
            students = list(collections['students'].find({"branch": selected_branch, "semester": int(selected_semester)}, {"_id": 0}))
        else:
            students = list(collections['students'].find({}, {"_id": 0}))
        # AJAX/JSON response
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            if error:
                return {"success": False, "message": error}
            else:
                return {"success": True, "message": message}
    else:
        # GET: show all students by default
        students = list(collections['students'].find({}, {"_id": 0}))
    return render_template('register_student_face.html', branches=branches, semesters=semesters, students=students, message=message, error=error, selected_branch=selected_branch, selected_semester=selected_semester, faculty=faculty_name)

@bp.route('/check_existing_registration')
def check_existing_registration():
    """Check if a student already has face registrations in any class"""
    from flask import session
    
    faculty_email = session.get('faculty_email')
    if not faculty_email:
        return jsonify({'error': 'Not logged in'}), 401
    
    student_id = request.args.get('student_id')
    if not student_id:
        return jsonify({'error': 'Missing student_id'}), 400
    
    # Get student info
    collections = get_collections()
    student = collections['students'].find_one({"roll_no": student_id})
    if not student:
        return jsonify({'error': 'Student not found'}), 404
    
    # Check all pickle files for this student's face
    split_dir = current_app.config['SPLIT_DIR']
    existing_registrations = []
    
    if os.path.exists(split_dir):
        all_pickle_files = [f for f in os.listdir(split_dir) if f.endswith('.pickle')]
        
        for pickle_file in all_pickle_files:
            pickle_path = os.path.join(split_dir, pickle_file)
            try:
                with open(pickle_path, 'rb') as f:
                    data = pickle.load(f)
                    existing_metadata = data.get('metadata', [])
                    
                    # Check if this student is in this class
                    for metadata in existing_metadata:
                        if metadata.get('roll_no') == student_id:
                            class_name = pickle_file.replace('.pickle', '')
                            branch, semester = class_name.split('_')
                            existing_registrations.append({
                                'class': class_name,
                                'branch': branch,
                                'semester': semester,
                                'section': metadata.get('section', 'A')
                            })
                            break
                            
            except (ModuleNotFoundError, ImportError, ValueError) as e:
                # Skip incompatible files
                continue
            except Exception as e:
                # Skip other errors
                continue
    
    return jsonify({
        'student_name': student.get('name', 'Unknown'),
        'student_roll': student.get('roll_no', 'Unknown'),
        'existing_registrations': existing_registrations
    })

@bp.route('/face_registrations_summary')
def face_registrations_summary():
    """Show a summary of all face registrations in the system"""
    from flask import session
    
    faculty_email = session.get('faculty_email')
    if not faculty_email:
        return redirect('/login')
    
    # Get faculty name
    faculty_map = pd.read_csv('faculty_users.csv')
    faculty_map['faculty_email'] = faculty_map['faculty_email'].str.strip().str.lower()
    faculty_map['faculty_name'] = faculty_map['faculty_name'].str.strip().str.lower()
    faculty_row = faculty_map[faculty_map['faculty_email'] == faculty_email.strip().lower()]
    if faculty_row.empty:
        flash("Faculty not found.", "error")
        return redirect('/login')
    faculty_name = faculty_row.iloc[0]['faculty_name']
    
    # Get all face registrations
    split_dir = current_app.config['SPLIT_DIR']
    all_registrations = []
    
    if os.path.exists(split_dir):
        all_pickle_files = [f for f in os.listdir(split_dir) if f.endswith('.pickle')]
        
        for pickle_file in all_pickle_files:
            pickle_path = os.path.join(split_dir, pickle_file)
            try:
                with open(pickle_path, 'rb') as f:
                    data = pickle.load(f)
                    encodings = data.get('encodings', [])
                    metadata = data.get('metadata', [])
                    
                    class_name = pickle_file.replace('.pickle', '')
                    branch, semester = class_name.split('_')
                    
                    for i, student_meta in enumerate(metadata):
                        all_registrations.append({
                            'student_name': student_meta.get('name', 'Unknown'),
                            'student_roll': student_meta.get('roll_no', 'Unknown'),
                            'class': class_name,
                            'branch': branch,
                            'semester': semester,
                            'section': student_meta.get('section', 'A'),
                            'encoding_index': i
                        })
                        
            except (ModuleNotFoundError, ImportError, ValueError) as e:
                # Skip incompatible files
                continue
            except Exception as e:
                # Skip other errors
                continue
    
    # Sort by class and then by student name
    all_registrations.sort(key=lambda x: (x['class'], x['student_name']))
    
    return render_template('face_registrations_summary.html', 
                         registrations=all_registrations, 
                         faculty=faculty_name) 