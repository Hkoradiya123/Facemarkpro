from flask import Blueprint, render_template, request, flash, redirect, url_for, session, current_app
import bcrypt
import pandas as pd
from datetime import datetime, timedelta
from collections import defaultdict
from ..db.mongo_client import get_collections

bp = Blueprint('faculty', __name__)

@bp.route('/')
def home():
    """Home route - redirect to dashboard if logged in, otherwise to login"""
    if 'faculty_email' in session:
        return redirect('/dashboard')
    return redirect('/multilogin')

@bp.route('/multilogin')
def multilogin():
    """Multi-login page"""
    if 'faculty_email' in session:
        return redirect('/dashboard')
    return render_template('multilogin.html')

@bp.route('/login', methods=['GET', 'POST'])
def login():
    """Faculty login"""
    role = request.args.get('role', 'teacher')
    collections = get_collections()

    if request.method == 'POST':
        email = request.form.get('faculty_email', '').strip().lower()
        password = request.form.get('password', '')

        print("[DEBUG] Submitted email:", email)
        print("[DEBUG] Submitted password:", password)

        if not email or not password:
            print("[DEBUG] Missing email or password.")
            flash("Please enter both email and password.", "error")
            return redirect(f'/login?role={role}')

        user = collections['users'].find_one({"email": email})
        print("[DEBUG] User lookup result:", user)
        if not user:
            print("[DEBUG] User not found in database.")
            flash("Invalid email or password.", "error")
            return redirect(f'/login?role={role}')

        hashed_password = user.get('password')
        print("[DEBUG] Hashed password from DB:", hashed_password)

        if not isinstance(hashed_password, bytes):
            print("[DEBUG] Password is not in byte format:", type(hashed_password))
            flash("Password format error.", "error")
            return redirect(f'/login?role={role}')

        password_check = bcrypt.checkpw(password.encode('utf-8'), hashed_password)
        print("[DEBUG] bcrypt.checkpw result:", password_check)
        if password_check:
            print("[DEBUG] Password MATCHED for:", email)
        else:
            print("[DEBUG] Password did NOT match for:", email)
            flash("Invalid email or password.", "error")
            return redirect(f'/login?role={role}')

        print("[DEBUG] Login successful for:", email)

        session['faculty_email'] = email
        session['role'] = user.get('role', role)
        session['faculty_name'] = user.get('name', 'Faculty')

        return redirect('/dashboard')

    return render_template('login.html', role=role)

@bp.route('/dashboard')
def dashboard():
    """Faculty dashboard with timetable and attendance stats"""
    faculty_email = session.get('faculty_email')
    if not faculty_email:
        return redirect('/login')

    # Get faculty name
    faculty_map = pd.read_csv('faculty_users.csv')
    faculty_map['faculty_email'] = faculty_map['faculty_email'].str.strip().str.lower()
    faculty_map['faculty_name'] = faculty_map['faculty_name'].str.strip().str.lower()
    faculty_row = faculty_map[faculty_map['faculty_email'] == faculty_email.strip().lower()]
    if faculty_row.empty:
        flash("Faculty not found.", "error")
        return redirect('/login')

    faculty_name = faculty_row.iloc[0]['faculty_name']

    # Load and filter timetable
    df = pd.read_csv('timetable.csv')
    df['faculty_name'] = df['faculty_name'].str.strip().str.lower()
    faculty_df = df[df['faculty_name'] == faculty_name]

    def get_status(row):
        try:
            start = datetime.strptime(row['start_time'], "%H:%M").time()
            end = datetime.strptime(row['end_time'], "%H:%M").time()
            now = datetime.now().time()
            if start <= now <= end:
                return 'current'
            elif now < start:
                return 'upcoming'
            else:
                return 'past'
        except:
            return 'past'

    faculty_df = faculty_df.copy()
    faculty_df['status'] = faculty_df.apply(get_status, axis=1)
    lectures = faculty_df.to_dict(orient='records')

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    time_slots = sorted(df['start_time'].unique(), key=lambda x: datetime.strptime(x, "%H:%M"))
    timetable = {(row['day'], row['start_time']): {'subject': row['subject'], 'classroom': row['classroom']} for _, row in faculty_df.iterrows()}

    today_str = datetime.now().strftime('%Y-%m-%d')
    collections = get_collections()
    class_attendance = defaultdict(int)
    for _, row in faculty_df.iterrows():
        query = {
            "date": today_str,
            "subject": row['subject'],
            "branch": row['branch'],
            "semester": row['semester'],
            "section": row['section'],
            "faculty_email": faculty_email,
            "student.status": "Present"
        }
        count = collections['attendance'].count_documents(query)
        class_attendance[f"{row['branch']}-{row['semester']}-{row['section']}"] += count

    today = datetime.now()
    thirty_days_ago = today - timedelta(days=30)
    monthly_trend = defaultdict(int)
    for doc in collections['attendance'].find({"faculty_email": faculty_email}):
        try:
            doc_date = datetime.strptime(doc.get("date", ""), "%Y-%m-%d")
            if thirty_days_ago <= doc_date <= today:
                if doc.get("student", {}).get("status") == "Present":
                    monthly_trend[doc_date.strftime("%Y-%m-%d")] += 1
        except:
            continue
    monthly_labels = sorted(monthly_trend.keys())
    monthly_data = [monthly_trend[date] for date in monthly_labels]

    matrix = defaultdict(lambda: defaultdict(int))
    for doc in collections['attendance'].find({"faculty_email": faculty_email}):
        subject = doc.get("subject", "?")
        classroom = doc.get("classroom", "?")
        if doc.get("student", {}).get("status") == "Present":
            matrix[subject][classroom] += 1

    bar_labels = sorted(matrix.keys())
    classroom_list = sorted(set(cls for subj in matrix.values() for cls in subj))
    bar_data = {cls: [matrix[subj].get(cls, 0) for subj in bar_labels] for cls in classroom_list}

    subject_labels = bar_labels
    classroom_labels = classroom_list
    heatmap_data = [
        {"x": j, "y": i, "v": matrix[subj].get(cls, 0)}
        for i, subj in enumerate(subject_labels)
        for j, cls in enumerate(classroom_labels)
    ]

    # --- Add logic for current, next, and upcoming lectures ---
    now = datetime.now().time()
    today = datetime.now().strftime('%A')
    today_lectures = [lec for lec in lectures if lec.get('day') == today]
    
    # Sort today's lectures by start_time
    def parse_time(t):
        try:
            return datetime.strptime(t, '%H:%M').time()
        except:
            return datetime.min.time()
    today_lectures_sorted = sorted(today_lectures, key=lambda x: parse_time(x['start_time']))
    
    current_lecture = None
    next_lecture = None
    upcoming_lectures = []
    for lec in today_lectures_sorted:
        start = parse_time(lec['start_time'])
        end = parse_time(lec['end_time'])
        if start <= now <= end:
            current_lecture = lec
        elif now < start:
            if not next_lecture:
                next_lecture = lec
            else:
                upcoming_lectures.append(lec)

    # If no current lecture, all future lectures are upcoming
    if not current_lecture and next_lecture:
        upcoming_lectures = today_lectures_sorted[today_lectures_sorted.index(next_lecture)+1:]

    # --- Calculate attendance stats for today (Present, Absent) ---
    attendance_stats = {'Present': 0, 'Absent': 0}
    for status in attendance_stats.keys():
        count = collections['attendance'].count_documents({
            "date": today_str,
            "faculty_email": faculty_email,
            "student.status": status
        })
        attendance_stats[status] = count

    # Fetch all students for this faculty's classes (for widget)
    students_list = []
    for branch, semester, section in faculty_df[['branch', 'semester', 'section']].drop_duplicates().to_records(index=False):
        students_cursor = collections['students'].find({
            "branch": branch,
            "semester": int(semester),
            "section": section
        })
        for s in students_cursor:
            students_list.append({
                "roll_no": str(s.get("roll_no")) if s.get("roll_no") is not None else "",
                "name": str(s.get("name")) if s.get("name") is not None else "",
                "branch": str(branch) if branch is not None else "",
                "semester": int(s.get("semester")) if s.get("semester") is not None else "",
                "section": str(s.get("section")) if s.get("section") is not None else ""
            })

    return render_template(
        'dashboard.html',
        faculty=faculty_name,
        lectures=lectures,
        days=days,
        time_slots=time_slots,
        timetable=timetable,
        class_attendance=class_attendance,
        monthly_labels=monthly_labels,
        monthly_data=monthly_data,
        bar_labels=bar_labels,
        classroom_list=classroom_list,
        bar_data=bar_data,
        heatmap_data=heatmap_data,
        subject_labels=subject_labels,
        classroom_labels=classroom_labels,
        current_lecture=current_lecture,
        next_lecture=next_lecture,
        upcoming_lectures=upcoming_lectures,
        attendance_stats=attendance_stats,
        students_list=students_list
    )

@bp.route('/logout')
def logout():
    """Logout faculty"""
    session.clear()
    return redirect('/login')

@bp.route('/change-password', methods=['GET', 'POST'])
def change_password():
    """Change faculty password"""
    collections = get_collections()

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        current_password = request.form.get('current_password', '')
        new_password = request.form.get('new_password', '')

        user = collections['users'].find_one({"_id": email})
        if not user or not bcrypt.checkpw(current_password.encode('utf-8'), user['password']):
            flash("Current password incorrect.", "error")
            return redirect('/change-password')

        new_hashed = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        collections['users'].update_one({"_id": email}, {"$set": {"password": new_hashed}})
        flash("Password changed successfully.", "success")
        return redirect('/change-password')

    return render_template("change_password.html") 